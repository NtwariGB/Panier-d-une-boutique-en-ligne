const catalog = [
    {
	    name : "Nounours marron",
	    description : "un joli nounours marron avec un foulard",
	    image : "images/nounours1.jpg",
		price : 35,
		qty : 5
	},
	{
	    name : "Nounours blanc",
	    description : "un ours blanc tout doux",
	    image : "images/nounours2.jpg",
	    price : 42,
	    qty : 5
	},
	{
	    name : "Peluche Ane gris",
	    description : "joli petit ane gris",
	    image : "images/ane.jpg",
	    price : 15,
	    qty : 5
	},
	{
	    name : "Pokemon Bulbizarre",
	    description : "Pokemon Bulbizarre",
	    image : "images/bulbizarre.jpg",
	    price : 25,
	    qty : 5
	},
	{
	    name : "Cochon rose",
	    description : "un petit cochon rose tout frippé",
	    image : "images/cochon.jpg",
	    price : 35,
	    qty : 5
	},
	{
	    name : "Donkey Kong",
	    description : "Le célèbre Donkey Kong",
	    image : "images/donkekong.jpg",
	    price : 25,
	    qty : 5
	},
	{
	    name : "Girafe",
	    description : "Petite girafe assise",
	    image : "images/girafe.jpg",
	    price : 23,
	    qty : 5
	},
	{
	    name : "Peluche Hibou",
	    description : "Un hibou tout en plume.",
	    image : "images/hibou.jpg",
	    price : 22,
	    qty : 5
	},
	{
	    name : "Link",
	    description : "Link le héros de la série Zelda.",
	    image : "images/link.jpg",
	    price : 25,
	    qty : 5
	},
	{
	    name : "Nounours crème",
	    description : "Il est pas migon avec ses grosses papattes ?",
	    image : "images/nounours3.jpg",
	    price : 35,
	    qty : 5
	},
	{
	    name : "Panda",
	    description : "Un bon gros pnada joufflu",
	    image : "images/panda.jpg",
	    price : 35,
	    qty : 5
	},
	{
	    name : "Pokemon Pikachu",
	    description : "Le plus célèbre des pokemons.",
	    image : "images/pikachu.jpg",
	    price : 25,
	    qty : 5
	},
	{
	    name : "Peluche Poule",
	    description : "Une idée originale de peluche",
	    image : "images/poule.jpg",
	    price : 27,
	    qty : 5
	},
	{
	    name : "Renard",
	    description : "Un renard très sympathique.",
	    image : "images/renard.jpg",
	    price : 45,
	    qty : 5
	},
	{
	    name : "Pokemon Riolu",
	    description : "Pokemon Riolu",
	    image : "images/riolu.jpg",
	    price : 25,
	    qty : 5
	},
	{
	    name : "Pokemon Salameche",
	    description : "Pokemon Salameche",
	    image : "images/salameche.jpg",
	    price : 25,
	    qty : 5
	}
];


