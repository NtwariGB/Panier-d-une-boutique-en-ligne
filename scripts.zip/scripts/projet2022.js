// BECHIR OUSMANE TOM et NTWARI GUY BENI

// ===  variables globales ===

// constantes
const MAX_QTY = 9;

//  tableau des produits à acheter
const cart = [];


// === initialisation au chargement de la page ===

/**
* Création du Magasin, mise à jour du total initial
* Mise en place du gestionnaire d'événements sur filter
*/
const init = function () {
	createShop();
	updateTotal();
	restaure();
	const filter = document.getElementById("filter");
	const achats = document.getElementsByClassName('achats');
  filter.addEventListener("keyup", filterDisplaidProducts);
	const button = document.createElement("button");
	button.id = "stock";
	button.textContent = "stocker";
	button.addEventListener("click",stockPanier);
	achats[0].appendChild(button);
}
window.addEventListener("load", init);



// ==================== fonctions utiles =======================

/**
* Crée et ajoute tous les éléments div.produit à l'élément div#boutique
* selon les objets présents dans la variable 'catalog'
*/
const createShop = function () {
	const shop = document.getElementById("boutique");
	for(let i = 0; i < catalog.length; i++) {
		shop.appendChild(createProduct(catalog[i], i));
	}
}

/**
* Crée un élément div.produit qui posséde un id de la forme "i-produit" où l'indice i
* est correpond au paramètre index
* @param {Object} product - le produit pour lequel l'élément est créé
* @param {number} index - l'indice (nombre entier) du produit dans le catalogue (utilisé pour l'id)
* @return {Element} une div.produit
*/
const createProduct = function (product, index) {
	// créer la div correpondant au produit
	const divProd = document.createElement("div");
	divProd.className = "produit";
	// fixe la valeur de l'id pour cette div
	divProd.id = index + "-product";
	// crée l'élément h4 dans cette div
	divProd.appendChild(createBlock("h4", product.name));

	// Ajoute une figure à la div.produit...
	// /!\ non fonctionnel tant que le code de createFigureBlock n'a pas été modifié /!\
	divProd.appendChild(createFigureBlock(product));

	// crée la div.description et l'ajoute à la div.produit
	divProd.appendChild(createBlock("div", product.description, "description"));
	// crée la div.prix et l'ajoute à la div.produit
	divProd.appendChild(createBlock("div", product.price, "prix"));
	// crée la div.controle et l'ajoute à la div.produit
	divProd.appendChild(createOrderControlBlock(index));
	return divProd;
}


/** Crée un nouvel élément avec son contenu et éventuellement une classe
 * @param {string} tag - le type de l'élément créé (example : "p")
 * @param {string} content - le contenu html de l'élément a créé  (example : "bla bla")
 * @param {string} [cssClass] - (optionnel) la valeur de l'attribut 'classe' de l'élément créé
 * @return {Element} élément créé
 */
const createBlock = function (tag, content, cssClass) {
	const element = document.createElement(tag);
	if (cssClass != undefined) {
		element.className =  cssClass;
	}
	element.innerHTML = content;
	return element;
}

/** Met à jour le montant total du panier en utilisant la variable globale total
 */
const updateTotal = function () {
	const montant = document.getElementById("montant");
	const panier = document.getElementsByClassName("achats");
	const lesPrix = panier[0].getElementsByClassName("prix");
	const lesQuantité = panier[0].getElementsByClassName("quantite");
	let sommes = 0
	for (i = 0; i < lesPrix.length; i++){
		p = parseInt(lesPrix[i].textContent);
		q = parseInt(lesQuantité[i].textContent);
		sommes += p*q;
	}
	montant.textContent = sommes ;
}

// ======================= fonctions à compléter =======================


/**
* Crée un élément div.controle pour un objet produit
* @param {number} index - indice du produit considéré
* @return {Element}
* TODO : AJOUTER les gestionnaires d'événements
*/
const createOrderControlBlock = function (index) {
	const control = document.createElement("div");
	control.className = "controle";

	// crée l'élément input permettant de saisir la quantité
	const input = document.createElement("input");
	input.id = index + "-qte";
	input.type = "number";
	input.step = "1";
	input.value = "0";
	input.min = "0";
	input.max = MAX_QTY.toString();

	// TODO :  Q5 mettre en place le gestionnaire d'événément pour input permettant de contrôler les valeurs saisies
	control.appendChild(input);
	input.addEventListener("change",verifQuantity);

	// Crée le bouton de commande
	const button = document.createElement("button");
	button.className = 'commander';
	button.id = index + "-order";
	control.appendChild(button);

	return control;
}


/**
* Crée un élément figure correspondant à un produit
* @param {Object} product -  le produit pour lequel la figure est créée
* @return {Element}
*/
const createFigureBlock = function (product) {
	// TODO : code incorrect : à modifier Q4
	const figure = document.createElement("figure");
	const image = document.createElement("img");
	image.src = product.image;
	image.alt = product.name;
	figure.appendChild(image);
	return figure
}


/**
remet à zéro la valeur de input et rend transparent le boutton et met en place l'abonnement de la fonction
addProductToCart
* @todo Q8
*/

const orderProduct = function () {
	const idx = parseInt(this.id);
	const input = document.getElementById(idx + "-qte");
	const qty = parseInt(input.value);
	if (qty > 0) {
	//	addProductToCart(idx, qty); // ajoute un produit au panier
		//TODO gérer la remise à zéro de la quantité après la commande
		// et tous les comportements du bouton représentant le chariot
		input.value = 0
		this.style.opacity = "0.33";
		this.addEventListener("click",addProductToCart(idx,qty));
	}
}


// ======================= fonctions à coder =======================

/**
* @todo Q6- Q7
*/
const verifQuantity = function () {
	//TODO
	const commander = document.getElementById(parseInt(this.id)+"-order");
	if (this.value > 0 && this.value <10 ){
		commander.style.opacity = "1";
	  commander.addEventListener("click",orderProduct);
	}
	else if (this.value > 9){
		this.value = 9
		commander.style.opacity = "1";
		commander.addEventListener("click",orderProduct);
	}
	else{
	   this.value = 0;
		 commander.style.opacity = "0.33"
	 }
}



/**
crée un élement div de classe achat, met à jour le montant du panier
* @todo Q9
* @param {number} index
* @param {number} qty
*/
const addProductToCart = function (index, qty) {
	//TODO
	const achats = document.getElementsByClassName("achats");
	if (verifCommande(index) != undefined){
		const i = verifCommande(index)
		const quantite = document.getElementsByClassName("quantite");
		ancienneQuantité = parseInt(quantite[i].textContent);
		if (ancienneQuantité + qty > 9)
		   quantite[i].textContent = 9
		else
		   quantite[i].textContent = ancienneQuantité + qty
	}
	else{
		const achat = document.createElement("div");
		const figur = document.getElementsByTagName("figure");
		achat.id = index + "-achat";
		achat.className = "achat";
		const clonefigur = figur[index].cloneNode(true);
		achat.appendChild(clonefigur);
		achat.appendChild(descriptions(index));
		achat.appendChild(quantité(qty,index));
		achat.appendChild(price(index));
	  achat.appendChild(buttonRetirer(index));
		achats[0].appendChild(achat);
		const buttonPlus = document.getElementById(index + "-plus");
		const buttonMoins = document.getElementById(index + "-moins");
		buttonPlus.addEventListener("click",ajouter);
		buttonMoins.addEventListener("click",diminuer);
	}
	updateTotal();
}

// fonction crée par les auteurs

/** cree un element h4 qui contient la description du produit ajouter au panier
*@param {number} index l'indice de l'element à ajouter au panier
*@return {element} h4 un element html
*/
const descriptions = function(index){
	const description = document.getElementsByClassName("description");
	const titre4 = document.createElement("h4");
	const clonedescription = description[index].cloneNode(true);
	titre4.appendChild(clonedescription);
	return titre4
}

/** verifie si l'article à ajouter existe déjà dans le panier
*@param {number} index l'indice de l'article
*@return {number} un nombre soit 1 si l'article est déjà dans le panier et rien sinon
*/
const verifCommande = function(index){
	const articles = document.getElementsByClassName("achat");
	for (let i = 0 ; i < articles.length; i++){
		if (articles[i].id == index + "-achat")
			return i
	}
}

/** cree un div de classe controle avec un noeud button de classe rétirer qui sera abonné à la fonction supprime par un événement de click
*@param {number} ind l'indice de l'article
*@return {element} un element HTML
*/
const buttonRetirer = function(ind){
	const controle = document.createElement("div");
	controle.className = "controle";
	const retirer = document.createElement("button");
	retirer.id = ind + "-remove";
	retirer.className = "retirer";
	controle.appendChild(retirer);
	retirer.addEventListener("click",supprime);
	return controle
}

/** cree un element div de class prix
*@param {number} ind l'indice de l'article à ajouter *
*@return {element} un element HTML
*/
const price = function(ind){
	const lesPrix = document.getElementsByClassName("prix")
	const clonePrix = lesPrix[ind].cloneNode(true);
  return clonePrix
}

/** retire un article du panier*/

const supprime = function(){
	const index = parseInt(this.id);
	const articles = document.getElementsByClassName("achat");
	for (let i = 0; i < articles.length; i++){
		if (articles[i].id == index + "-achat")
		 articles[i].parentNode.removeChild(articles[i]);
	}
	updateTotal();
}

/** crée un element div contenant un element div de classe quantite et deux boutton
*@param {number} qty la quantité de l'article commander
*@param {number} idx l'indice de l'article commander
*@return {element} un element HTML
*/
const quantité = function(qty,idx){
	const div = document.createElement("div");
	const buttonPlus = document.createElement("button");
	buttonPlus.id = idx + "-plus";
	buttonPlus.className = "plus";
	buttonPlus.textContent = "+"
	div.appendChild(buttonPlus);
	const buttonMoins = document.createElement("button");
	buttonMoins.id = idx + "-moins";
	buttonMoins.className = "moins";
	buttonMoins.textContent = "-";
	div.appendChild(buttonMoins);
	const divQty = document.createElement("div");
	divQty.className = "quantite";
	divQty.id = idx + "-quantite";
	divQty.textContent = qty;
	div.appendChild(divQty);
	return div;
}

/** augmente la valeur du contenue de div de classe quantite et met à jour le totale du panier*/
const ajouter = function(){
	const idx = parseInt(this.id);
	const quantite = document.getElementById(idx + "-quantite");
	let qty = parseInt(quantite.textContent);
	if(qty + 1 <= 9){
		quantite.textContent = qty + 1;
	  updateTotal()
	}
}

/** dimunue la valeur du contenue de div de classe quantite et met à jour le tptale du panier*/
const diminuer = function(){
	const index = parseInt(this.id);
	const quantite = document.getElementById(index + "-quantite");
	let qty = parseInt(quantite.textContent);
	if (qty - 1 > 0)
	 quantite.textContent = qty - 1;
	else {
		if (confirm("voulez-vous retirer l'article du panier?")){
			 const achat = document.getElementById(index + "-achat");
			 achat.parentNode.removeChild(achat);
		 }
		else
			quantite.textContent = 1;
	}
	updateTotal();
}

/**fais une mise à jour du contenu du noeud div d'id boutique
* @todo Q10
*/
const filterDisplaidProducts = function () {
	const filtre = document.getElementById("filter");
	const boutique = document.getElementById("boutique");
	const lesNoms = boutique.getElementsByTagName("h4");
	for (i = 0 ; i < catalog.length; i++)
		catalog[i]["idx"] = i;
  while (boutique.firstChild){
		 boutique.removeChild(boutique.firstChild);
	 }
	for (let i = 0 ; i < catalog.length; i++){
		if (catalog[i].name.indexOf(filtre.value) != -1 )
			boutique.appendChild(createProduct(catalog[i],catalog[i].idx));
		}

}

/** stock dans le navigateur l'indice et la quantité de chaque achat present dans le panier*/
const stockPanier = function(){
	const achat = document.getElementsByClassName("quantite");
	let array = [];
	for (let i = 0; i < achat.length; i++)
	  array.push({index : parseInt(achat[i].id),
								qty : parseInt(achat[i].textContent)});
  localStorage.setItem("panier",JSON.stringify(array));
}

/** restaure le cotenue du panier comme il etait après le rafraichissement de la page*/
const restaure = function(){
	const stock = JSON.parse(localStorage.getItem("panier"));
	for (let i = 0; i < stock.length; i++)
		addProductToCart(stock[i].index,stock[i].qty);
}
window.addEventListener("load",restaure);
